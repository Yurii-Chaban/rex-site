    <form action="" role="search" method="get" id="searchform" action="<?php echo home_url('/'); ?>">
        <input id="search s" name="search s" type="text" placeholder="What're you looking for ?">
        <input id="search_submit" value="Search" type="submit">
    </form>